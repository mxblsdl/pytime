# Pytime

A command line utility for logging time through out the day

A new WIP

Basic concept:
- connects to sqlite
- adds time to specific set of projects
- function for adding time/project
- defaults to today, can do set days back
- can output a report of time
- Rounding feature for time less than 8 hours?