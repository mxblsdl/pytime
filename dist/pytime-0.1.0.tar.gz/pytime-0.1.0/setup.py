# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pytime']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['pytime = pytime.main:app']}

setup_kwargs = {
    'name': 'pytime',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Pytime\n\nA command line utility for logging time through out the day\n\nA new WIP\n\nBasic concept:\n- connects to sqlite\n- adds time to specific set of projects\n- function for adding time/project\n- defaults to today, can do set days back\n- can output a report of time\n- Rounding feature for time less than 8 hours?',
    'author': 'mxblsdl',
    'author_email': 'maxblasdel@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
